<a href="<?php echo base_url('admin/produk/detail/'.$produk->id_produk) ?>" class="btn btn-success btn-sm" data-toggle="modal" data-target="#Detail<?php echo $i ?>">
    <i class="fa fa-eye"></i>
</a>
<div class="modal fade" id="Detail<?php echo $i ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog modal-lg">
<div class="modal-content">

</div>
</div>
</div>
